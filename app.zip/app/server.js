const express= require('express');
const mysql= require('mysql');
const app= express();
const PORT= process.env.PORT ?? 8000;

app.use(express.static(__dirname + '/public'));

 app.set('view engine','ejs')

const connection= mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'restaurant'
})

connection.connect((err)=>{
    if(err){
        throw err
    }else{
        console.log('database connecting')
    }
})

app.get('/Home',(req,res)=>{
    let row;
    connection.query('select * from pizza',(err, data)=>{
        if(err){
            throw err
        }else{
           row= data
        }
        res.render('Home',{title:'Home',row,active:'shop'})
    })
 
  
})

app.get('/order/id=:id',(req,res)=>{
  
    let id= req.params.id
    let price;
    let  name;
    let picture;
   let datas;
   connection.query('select picture,price,name from pizza where id='+id,(err,data)=>{
       if(err){
           throw err
       }else{
            data.forEach(element => {
                picture=element['picture'];
                price= element['price'];
                name= element['name']
            });
            connection.query('select * from ingredient',(err,result)=>{
                if(err){
                    throw err
                }else{
                    datas=result
                }
                res.render('order',{title:'Order',picture,price,name,datas,active:''})
            })
       
       }
       
   })
   
})









app.listen(PORT,()=>{
    console.log('server runn onnn port '+ PORT)
})